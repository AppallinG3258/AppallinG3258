package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private SharedPreferences sharedPreferences;
    private EditText usernameEditText;
    private Button saveButton;
    private Button clearButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        usernameEditText = view.findViewById(R.id.editTextUsername);
        saveButton = view.findViewById(R.id.buttonSave);
        clearButton=view.findViewById(R.id.clearbutton);
        sharedPreferences = requireContext().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);

        // Load saved username
        String savedUsername = sharedPreferences.getString("username", "");
        usernameEditText.setText(savedUsername);

        // Save username on button click
        saveButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
           //Exam// sharedPreferences.edit().putString("username", username).apply();
            Log.d("ProfileFragment", "Username saved: " + username);
            Toast.makeText(getContext(), "Username saved", Toast.LENGTH_SHORT).show();
        });
            clearButton.setOnClickListener(v -> {
                usernameEditText.setText("");
               //Exam// sharedPreferences.edit().remove("username").apply();
                Log.d("ProfileFragment", "Username cleared");
                Toast.makeText(getContext(), "Username cleared", Toast.LENGTH_SHORT).show();
            });
        return view;
    }
}
