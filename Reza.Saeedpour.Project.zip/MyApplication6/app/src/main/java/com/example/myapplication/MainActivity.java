package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private Button loginButton;
    private Button registerButton;
    private EditText emailInput;
    private EditText passwordInput;
    private DbManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        dbManager = new DbManager(this);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.btnSign);
        emailInput = findViewById(R.id.emailEditText);
        passwordInput = findViewById(R.id.passwordEditText);

        loginButton.setOnClickListener(v -> handleLogin());
        registerButton.setOnClickListener(v -> handleSignUp());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void handleLogin() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (email.isEmpty()) {
            showToast("Please provide your email.");
        } else if (password.isEmpty()) {
            showToast("Please provide your password.");
        } else {
            authenticateUser(email, password);
        }
    }

    private void handleSignUp() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (email.isEmpty()) {
            showToast("Email is required to register.");
        } else if (password.isEmpty()) {
            showToast("Password is required to register.");
        } else {
            registerNewUser(email, password);
        }
    }

    private void authenticateUser(String email, String password) {
        if (dbManager.login(email, password)) {
            showToast("Welcome back, " + email + "!");
            navigateToHome();
        } else {
            showToast("Invalid email or password.");
        }
    }

    private void registerNewUser(String email, String password) {
        if (dbManager.signUp(email, password)) {
            showToast("Registration successful for " + email + "!");
            navigateToHome();
        } else {
            showToast("This email is already registered.");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void navigateToHome() {
        startActivity(new Intent(this, MainActivity2.class));
        finish();
    }
}
