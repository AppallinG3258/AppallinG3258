package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbManager extends SQLiteOpenHelper {
    public static final String DB_NAME = "stu.db";
    public static final int DB_VERSION = 1;

    public DbManager(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table student(id INTEGER primary key AUTOIncrement, name varchar(25), password varchar(25))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists student");
        onCreate(db);
    }

    public Boolean login(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(
                "select * from student where name=? AND password=?",
                new String[]{username, password}
        );
        boolean success = c.getCount() == 1;
        c.close();
        return success;
    }

    public Boolean signUp(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(
                "select * from student where name=?",
                new String[]{username}
        );
        boolean exist = c.getCount() == 1;
        c.close();
        if (exist) return false;
        ContentValues values = new ContentValues();
        values.put("name", username);
        values.put("password", password);
        long a = db.insert("student", null, values);
        return a != -1;
    }
}
